import unittest

class PaymentReturnTest(unittest.TestCase):
    def test_PaymentReturnByBank(self):
        print("This is Payment Return By Bank test")
        self.assertTrue(True)

if __name__ == "__main__":
    unittest.main()